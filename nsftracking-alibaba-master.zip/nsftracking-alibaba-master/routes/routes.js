var request = require('request');
var JwtGenerator = require('../services/jwtgenerator');
var localStorage = require('localStorage');
var moment = require('moment');
var event = require('events');
var crypto = require('crypto');
var eventEmitter = new event.EventEmitter();

var mysqlconnect = require('../db-config/dbconfig');
var Images = ['http://www.clker.com/cliparts/Q/E/9/o/7/1/factory-building.svg',
    'https://www.centrafoods.com/hs-fs/hub/260019/file-380287009-jpg/images/Blog10-Supplier-of-Drum-35Lber-and-Gallon-Cartoon-a.jpg?t=1530033929214',
    'https://d2gg9evh47fn9z.cloudfront.net/800px_COLOURBOX23651598.jpg'
];


eventEmitter.on('Assetaddedevent', (args) => {
    console.log(args.body);
});
eventEmitter.on('TransferSingleasset', (args) => {
        console.log(args.body);
    }),
    eventEmitter.on('Inactivateasset', (args) => {
        console.log(args.body);
    });
module.exports = (app) => {
    // Index Page
    app.get('/', function (req, res) {
        var card = localStorage.getItem('card');
        if (card) {
            res.redirect('/dashboard');
        } else {
            res.render('index');
        }
    });
    // Get All Users
    app.get('/participants', activateCard, (req, res) => {
        require('../services/getparticipants')(req,res);
    });
    // Track Product Sticker
    app.get('/assettracker', activateCard, (req, res) => {
        res.render('assettracker', {
            records: [],
            assetId: ''
        });
    });

    app.post('/trackasset', activateCard, (req, res) => {
        require('../services/trackassets')(req,res);
    });
    // Add User Page
    app.get('/newuser', (req, res) => {
        res.render('newuser');
    });
    // Add New User
    app.post('/adduser', (req, res) => {
        require('../services/addUser')(req.body.user,req.body.type,req,res);
    });
    // Post Request to Get Token
    app.post('/userlogin', Verifyaccount, (req, res) => {
        try {
                res.redirect('/dashboard');
            
        } catch (error) {
            console.log(error);
        }
    });

    app.get('/dashboard', activateCard, (req, res) => {
        require('../services/dashboard')(req,res);
    });
    app.post('/nsftrackingauth', (req, res) => {
        try {
            var JwtToken = JwtGenerator(req.body.username);
            var cardName = req.body.cardname;
            //res.send(JwtToken);
            let options = {
                method: 'GET',
                url: 'http://47.100.233.7:3000/auth/jwt/callback?token=' + JwtToken,
                maxRedirects: '3',
                followRedirect: false
            };

            request(options, function (error, response, body) {
                // upon a successful request, cookies are stored in response.headers['set-cookie']
                var name = "access_token=";
                console.log('Token Request Recieved');
                var access_token = '';
                var ca = decodeURIComponent(response.headers['set-cookie'][0]).split(';');
                for (var i = 0; i < ca.length; i++) {
                    var c = ca[i];
                    while (c.charAt(0) == ' ') {
                        c = c.substring(1);
                    }
                    if (c.indexOf(name) == 0) {
                        access_token = c.substring(name.length, c.length);
                    }
                }
                var matches = access_token.match(/^s:(.+?)\./);
                /* eventEmitter.emit('token_added');
                res.json({
                    access_token: matches[1],
                    jwttoken: JwtToken
                }); */
                require('../services/activateWalletCard')(matches[1], false, cardName, req, res);

            });
        } catch (error) {
            console.log(error);
        }
    });
    app.get('/historian', activateCard, function (req, res) {
        require('../services/historian')(req,res);
    });

    app.post('/addssset', function (req, res) {
        require('../services/addasset')(req,res);
    });

    app.get('/assets', activateCard, (req, res) => {
        require('../services/getassets')(req,res);
    });

    app.get('/transferasset/:assetid', activateCard, (req, res) => {
        var card = localStorage.getItem('card');
        if (card) {
            res.render('transferasset', {
                assetId: req.params.assetid
            });
        } else {
            res.redirect('/');
        }
    });

    app.post('/transfer', (req, res) => {
        require('../services/transferassets')(req,res);
    });
    app.get('/inactivate/:assetId', (req, res) => {
        res.render('inactivateasset', {
            assetId: req.params.assetId
        });
    });
    app.post('/inactivateasset', (req, res) => {
        require('../services/inactivateassets')(req,res);
    });

    app.get('/logout', (req, res) => {
        localStorage.clear();
        res.redirect('/');
    });

    app.post('/addhashedasset',(req,res)=>{
        require('../services/hashedasset')(req,res);
    });

}

function activateCard(req, res, next) {
    var card = localStorage.getItem('card');
    if (card) {
        next();
    } else {
        res.redirect('/');
    }
}

function Verifyaccount(req, res, next) {
    let username = req.body.username;
    localStorage.setItem('username', username);
    let type = req.body.usertype;
    if (username && type) {
        mysqlconnect.query('SELECT * FROM users where user = ? and type = ?', [username, type], (error, result) => {
            if (error) {
                res.send('Error Connecting to DB');
            } else {
                let count = result.length;
                if (count == '1') {
                    //let data = JSON.parse(result[0]);
                    localStorage.setItem('card', result[0].card);
                    req.card = result[0].card;
                    next();
                } else {
                    res.json({
                        'message': 'Wrong Auth Details',
                        'status': 'Wrong user Information!'
                    });
                }
            }
        })
    } else {
        res.redirect('/');
    }
}


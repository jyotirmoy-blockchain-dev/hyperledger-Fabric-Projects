-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.2
-- Generation Time: Nov 02, 2018 at 11:52 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `users`
--

-- --------------------------------------------------------

--
-- Table structure for table `bx_basic_certcode`
--

CREATE TABLE `bx_basic_certcode` (
  `Id` int(11) NOT NULL,
  `Code` varchar(100) NOT NULL,
  `SerialNumber` varchar(100) NOT NULL,
  `AuthUrl` varchar(100) DEFAULT NULL,
  `APIFactory` varchar(100) DEFAULT NULL,
  `ManufacturerId` int(11) DEFAULT NULL,
  `DistributedAt` datetime DEFAULT NULL,
  `CertItemId` int(11) DEFAULT NULL,
  `BindedAt` datetime DEFAULT NULL,
  `Attachments` varchar(1000) DEFAULT NULL,
  `CreatedById` varchar(50) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `ModifiedById` varchar(50) DEFAULT NULL,
  `ModifiedAt` datetime DEFAULT NULL,
  `IsDeleted` tinyint(1) NOT NULL DEFAULT '0',
  `DeletedById` varchar(50) DEFAULT NULL,
  `DeletedAt` datetime DEFAULT NULL,
  `BatchId` int(11) DEFAULT NULL,
  `IsReturn` tinyint(1) NOT NULL,
  `State` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bx_basic_certcode`
--

INSERT INTO `bx_basic_certcode` (`Id`, `Code`, `SerialNumber`, `AuthUrl`, `APIFactory`, `ManufacturerId`, `DistributedAt`, `CertItemId`, `BindedAt`, `Attachments`, `CreatedById`, `CreatedAt`, `ModifiedById`, `ModifiedAt`, `IsDeleted`, `DeletedById`, `DeletedAt`, `BatchId`, `IsReturn`, `State`) VALUES
(7, '1236547887456321', '100', 'A1-1236547887456321', 'CCN', 1, '2018-07-12 14:43:33', NULL, NULL, NULL, '4', '2018-07-12 14:31:54', '4', '2018-07-12 14:43:33', 1, NULL, NULL, NULL, 0, 'OutStock');

-- --------------------------------------------------------

--
-- Table structure for table `sticke_details`
--

CREATE TABLE `sticke_details` (
  `Id` int(11) NOT NULL,
  `code` varchar(255) NOT NULL,
  `partType` varchar(255) NOT NULL,
  `Vin` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sticke_details`
--

INSERT INTO `sticke_details` (`Id`, `code`, `partType`, `Vin`) VALUES
(1, '', '', ''),
(2, '', '', ''),
(3, '', '', ''),
(4, '', '', ''),
(5, '', '', ''),
(6, '', '', ''),
(7, '', '', ''),
(8, '', '', ''),
(9, '', '', ''),
(10, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `card` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `user`, `card`, `type`) VALUES
(1, 'Jyotirmoy', 'NSF1', 'NSF'),
(3, 'Pravesh', 'MFG1', 'MANUFACTURER'),
(4, 'Sunil', 'DL1', 'DEALER'),
(5, 'Gunjan', 'RS1', 'REPAIR_SHOP');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bx_basic_certcode`
--
ALTER TABLE `bx_basic_certcode`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `ManufacturerId` (`ManufacturerId`),
  ADD KEY `CertItemId` (`CertItemId`),
  ADD KEY `CreatedById` (`CreatedById`),
  ADD KEY `ModifiedById` (`ModifiedById`),
  ADD KEY `DeletedById` (`DeletedById`),
  ADD KEY `BatchId` (`BatchId`);

--
-- Indexes for table `sticke_details`
--
ALTER TABLE `sticke_details`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bx_basic_certcode`
--
ALTER TABLE `bx_basic_certcode`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `sticke_details`
--
ALTER TABLE `sticke_details`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

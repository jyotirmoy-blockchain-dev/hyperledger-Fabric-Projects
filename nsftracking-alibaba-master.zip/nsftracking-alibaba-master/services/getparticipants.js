var request = require('request');
var JwtGenerator = require('../services/jwtgenerator');
var localStorage = require('localStorage');

module.exports = (req,res)=>{
    let options = {
        method: 'GET',
        url: 'http://47.100.233.7:3000/api/org.nsf.tracking.Owner'
    };
    request(options, (error, response, body) => {
        if (error) {
            res.send(error);
        } else {
            res.render('participants', {
                owners: JSON.parse(body)
            });
        }
    });
}
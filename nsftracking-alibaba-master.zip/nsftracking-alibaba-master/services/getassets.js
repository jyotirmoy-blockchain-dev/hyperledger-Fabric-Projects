var request = require('request');
var JwtGenerator = require('../services/jwtgenerator');
var localStorage = require('localStorage');

module.exports = (req,res)=>{
    var card = localStorage.getItem('card');
    if (card) {
        let options = {
            method: 'GET',
            url: 'http://47.100.233.7:3000/api/queries/getParticipantAssets?owner=resource%3Aorg.nsf.tracking.Owner%23' + card
        };
        request(options, (error, response, body) => {
            if (error) {
                res.send(error);
            } else {
                res.render('assets', {
                    assets: JSON.parse(body),
                    card: card
                });
            }
        });
    } else {
        res.redirect('/');
    }
}
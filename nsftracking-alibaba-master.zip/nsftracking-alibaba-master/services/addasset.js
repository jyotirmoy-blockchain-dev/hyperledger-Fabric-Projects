var request = require('request');
var JwtGenerator = require('../services/jwtgenerator');
var localStorage = require('localStorage');
var crypto = require('crypto');
var mysqlconnect = require('../db-config/dbconfig');

module.exports = (req,res)=>{
    mysqlconnect.query('insert into sticke_details values()');
    var secret = 'gSi4WmttWuvy2ewoTGooigPwSDoxwZOy';
    const stickerHashCode = crypto.createHmac('sha256', secret)
        .update(req.body.stickerid + "#NSF1" + "ACTIVE")
        .digest('hex');
    let send_data = {
        "$class": "org.nsf.tracking.addAsset",
        "stickerId": req.body.stickerid,
        "stickerHashCode": stickerHashCode,
        "status": "ACTIVE",
        "newOwner": "resource:org.nsf.tracking.Owner#NSF1"
    };
    let options = {
        method: 'POST',
        url: 'http://47.100.233.7:3000/api/org.nsf.tracking.addAsset',
        form: send_data
    };
    request(options, (error, response, body) => {
        //console.log(response);
        let errorStatus = JSON.parse(body);
        if (errorStatus.error) {
            res.status(500).send(errorStatus.error.message);
        } else {
            res.redirect('/assets');
        }
    });
}
var request = require('request');
var localStorage = require('localStorage');
module.exports = function (user,type, req, res)  {

    const send_data = {
        "$class": "org.nsf.tracking.addParticipant",
        "ownerId": user,
        "type": type,
        "assetCount": "0"
    };
    var token = localStorage.getItem('access_token');
    let options = {
        method: 'POST',
        url: 'http://47.100.233.7:3000/api/org.nsf.tracking.addParticipant',
        headers: {
            'X-Access-Token': token
        },
        form: send_data
    };
    request(options, (error, response, body) => {
        if (error) {
            res.send(error);
        } else {
            
            let errorStatus = JSON.parse(body);
            if (errorStatus.error) {
                res.status(500).send(errorStatus.error.message);
            } else {
                require('./issueidentity')(user,req,res);
            }
        }
    });
}
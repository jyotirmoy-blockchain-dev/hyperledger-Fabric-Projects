var request = require('request');
var JwtGenerator = require('../services/jwtgenerator');
var localStorage = require('localStorage');

module.exports = (req,res)=>{
    let send_data = {
        "$class": "org.nsf.tracking.transferAsset",
        "sticker": "resource:org.nsf.tracking.Productsticker#" + req.body.assetId,
        "newOwner": "resource:org.nsf.tracking.Owner#" + req.body.owner
    };
    let options = {
        method: 'POST',
        url: 'http://47.100.233.7:3000/api/org.nsf.tracking.transferAsset',
        form: send_data
    };
    request(options, (error, response, body) => {
        if (error) {
            res.send(error);
        } else {
            let errorStatus = JSON.parse(body);
            if (errorStatus.error) {
                res.status(500).send(errorStatus.error.message);
            } else {
                res.redirect('/assets');
            }
        }
    });
}
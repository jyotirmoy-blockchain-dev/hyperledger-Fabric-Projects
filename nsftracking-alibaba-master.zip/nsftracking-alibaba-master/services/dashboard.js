var request = require('request');
var JwtGenerator = require('../services/jwtgenerator');
var localStorage = require('localStorage');
module.exports = (req,res)=>{
    var token = localStorage.getItem('access_token');
    var card = localStorage.getItem('card');
    var username = localStorage.getItem('username');
    if (card == "NSF1") {
        let options = {
            method: 'GET',
            url: 'http://47.100.233.7:3000/api/org.nsf.tracking.Productsticker'
        };
        request(options, (error, response, body) => {
            if (error) {
                res.send(error);
            } else {
                res.render('dashboard', {
                    token: token,
                    card: card,
                    username: username,
                    assets: JSON.parse(body)
                });
            }
        });
    } else {
        res.render('dashboard', {
            token: token,
            card: card,
            username: username
        });
    }
    //

}
var request = require('request');
var JwtGenerator = require('../services/jwtgenerator');
var localStorage = require('localStorage');
var moment = require('moment');
module.exports = (req,res)=>{
    var token = localStorage.getItem('access_token');
    let options = {
        method: 'GET',
        url: 'http://47.100.233.7:3000/api/system/historian'
    };
    request(options, (error, response, body) => {
        if (error) {
            res.send(error);
        } else {
            let responseresult = JSON.parse(body);
            responseresult.sort(function (a, b) {
                return new Date(a.transactionTimestamp) - new Date(b.transactionTimestamp);
            });
            var newResult = responseresult.map(item => {
                let obj = item;
                obj.transactionTimestamp = moment(item.transactionTimestamp).format('MMMM Do YYYY, h:mm:ss a');
                return obj;
            });
            res.render('historian', {
                historyrecords: newResult
            });
        }
    });
}
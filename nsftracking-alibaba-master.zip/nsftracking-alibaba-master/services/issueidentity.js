var request = require('request');
var localStorage = require('localStorage');
var fs = require("fs");
var fileSaver = require('file-saver');
module.exports = function(user,req,res){
    var token = localStorage.getItem('access_token');
    const send_data = {
        "participant": "org.nsf.tracking.Owner#"+user,
        "userID": user,
        "options": {}
    };
    let options = {
        method: 'POST',
        url: 'http://47.100.233.7:3000/api/system/identities/issue',
        headers: {
            'X-Access-Token': token
        },
        form: send_data
    };
    request(options, (error, response, body) => {
        if (error) {
            res.send(error);
        } else {

            if (typeof body === 'object') {
                let errorStatus = JSON.parse(body);
                if (errorStatus.error) {
                    res.status(500).send(errorStatus.error.message);
                }
            }
            else {
                //require('../services/importcard')(user,body,req,res);
                // decode               
               var fileName = user+".card";
               fileSaver.saveAs(body, fileName);
               res.redirect('/participants');
               //saveAs(body, fileName);
            }
        }
    });
}
var request = require('request');
var JwtGenerator = require('../services/jwtgenerator');
var localStorage = require('localStorage');
var moment = require('moment');
module.exports = (req,res)=>{
    let token = localStorage.getItem('access_token');
    let id = req.body.assetId;
    let  Images = ['http://www.clker.com/cliparts/Q/E/9/o/7/1/factory-building.svg',
          'https://www.centrafoods.com/hs-fs/hub/260019/file-380287009-jpg/images/Blog10-Supplier-of-Drum-35Lber-and-Gallon-Cartoon-a.jpg?t=1530033929214',
          'https://d2gg9evh47fn9z.cloudfront.net/800px_COLOURBOX23651598.jpg'
      ]
    let options = {
        method: 'GET',
        url: 'http://47.100.233.7:3000/api/queries/selectAssetTransfers?stickerid=resource%3Aorg.nsf.tracking.Productsticker' + "%23" + id,
        headers: {
            'X-Access-Token': token
        }
    };
    request(options, (error, response, body) => {
        if (error) {
            res.send(error);
        } else {
            let responseresult = JSON.parse(body);
            /*var newResult = responseresult.map(item=>{
                let obj = item;
                obj.timestamp = moment(item.timestamp).format('MMMM Do YYYY, h:mm:ss a');
                return obj;
            });            
            console.log(newResult);*/
            responseresult.sort(function (a, b) {
                return new Date(a.timestamp) - new Date(b.timestamp);
            });
            var newResult = responseresult.map(item => {
                let obj = item;
                obj.timestamp = moment(item.timestamp).format('MMMM Do YYYY, h:mm:ss a');
                return obj;
            });
            //console.log(newResult);
            res.render('assettracker', {
                records: newResult,
                assetId: id,
                Images: Images
            });
        }
    });
}
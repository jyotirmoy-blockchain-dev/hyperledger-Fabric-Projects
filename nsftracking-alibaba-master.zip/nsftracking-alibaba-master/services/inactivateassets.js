var request = require('request');
var JwtGenerator = require('../services/jwtgenerator');
var localStorage = require('localStorage');

module.exports = (req,res)=>{
    var token = localStorage.getItem('access_token');
    let send_data = {
        "$class": "org.nsf.tracking.inactivateAsset",
        "sticker": "resource:org.nsf.tracking.Productsticker#" + req.body.assetId
    };
    let options = {
        method: 'POST',
        url: 'http://47.100.233.7:3000/api/org.nsf.tracking.inactivateAsset',
        form: send_data
    };
    request(options, (error, response, body) => {
        if (error) {
            res.send(error);
        } else {
            //res.send(response);
            let errorStatus = JSON.parse(body);
            if (errorStatus.error) {
                res.status(500).send(errorStatus.error.message);
            } else {
                res.redirect('/assets');
            }
        }
    });
}
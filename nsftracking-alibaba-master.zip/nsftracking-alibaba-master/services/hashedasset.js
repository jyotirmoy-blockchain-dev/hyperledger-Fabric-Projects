var crypto = require('crypto');
var mysqlconnect = require('../db-config/dbconfig');
var request = require('request');
var localStorage = require('localStorage');

module.exports = function(req, res){
    var secret = 'gSi4WmttWuvy2ewoTGooigPwSDoxwZOy';
    mysqlconnect.query('SELECT * FROM bx_basic_certcode', (error, result) => {
        if (error) {
            res.send(error);
        } else {
            
            let responseObj = {
                'Id':result[0].Id,
                'code': result[0].Code,
                'SerialNumber':result[0].SerialNumber,
                'ManufacturerId': result[0].ManufacturerId
            };
            let NewObj = JSON.stringify(responseObj);
            const hash = crypto.createHmac('sha256', secret)
                .update(NewObj)
                .digest('hex');
            var token = localStorage.getItem('access_token');
            let send_data = {
                "$class": "org.nsf.tracking.addAsset",
                "stickerId": Date.now(),
                "stickerHashCode": hash,
                "status": "ACTIVE",
                "newOwner": "resource:org.nsf.tracking.Owner#NSF1"
            };
            let options = {
                method: 'POST',
                url: 'http://47.100.233.7:3000/api/org.nsf.tracking.addAsset',
                form: send_data
            };
            request(options, (error, response, body) => {
                //console.log(response);
                let errorStatus = JSON.parse(body);
                if (errorStatus.error) {
                    res.status(500).send(errorStatus.error.message);
                } else {
                    res.redirect('/assets');
                }
            });
        }
    });
}
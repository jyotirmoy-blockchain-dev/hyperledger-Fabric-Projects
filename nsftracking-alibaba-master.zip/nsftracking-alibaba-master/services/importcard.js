var request = require('request');
var localStorage = require('localStorage');
var FormData = require('form-data');
module.exports = (cardname,card,req,res)=>{
     var token = localStorage.getItem('access_token');
     let send_data = new FormData();
     send_data.append('card',card);
     let options = {
         method: 'POST',
         url: 'http://47.100.233.7:3000/api/wallet/import?name='+cardname,
         headers: {
             'X-Access-Token': token,
             'responseType': 'blob'
         },
         form: send_data
     };
     request(options,(error,response,body)=>{
         res.send(body);
     });
}
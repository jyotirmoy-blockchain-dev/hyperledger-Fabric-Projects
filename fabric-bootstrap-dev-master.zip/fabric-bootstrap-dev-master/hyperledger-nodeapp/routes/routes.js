const BusinessNetworkConnection = require('composer-client').BusinessNetworkConnection;
var bizNetworkConnection = new BusinessNetworkConnection();


module.exports = (app)=>{
    app.get('/getassets',(req,res)=>{
        console.log('Get Assets Route Called');
        require('../services/getassets')(req,res);        
    });
    app.get('/participants',(req,res)=>{
        console.log('Get Participants Route called');
        require('../services/getparticipants')(req,res);
    });
    app.post('/newparticipant',(req,res)=>{
        console.log('Add new Participant');
        require('../services/addParticipant')(req,res);
    });
    app.post('/newasset',(req,res)=>{
        console.log('Add new Asset');
        require('../services/addAsset')(req,res);
    });
}

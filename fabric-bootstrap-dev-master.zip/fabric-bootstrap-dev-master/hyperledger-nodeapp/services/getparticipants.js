const BusinessNetworkConnection = require('composer-client').BusinessNetworkConnection;
var bizNetworkConnection = new BusinessNetworkConnection();

module.exports = async function getStickers(req, res) {   
    var cardName = 'admin@nsf-tracking-network';
    var businessNetworkDefinition = await bizNetworkConnection.connect(cardName);
        let registry = await bizNetworkConnection.getParticipantRegistry('org.nsf.tracking.Owner');
        let aResources = await registry.getAll();
    console.log(aResources);
    let responseArray = [];
    let arrayLength = aResources.length;
    for (let i = 0; i < arrayLength; i++) {
        responseArray.push({
            'ownerId': aResources[i].ownerId,
            'type': aResources[i].type,
            'assetCount': aResources[i].assetCount
        });
    }
    let responseObject = JSON.stringify(responseArray);
    res.json(responseArray);

}
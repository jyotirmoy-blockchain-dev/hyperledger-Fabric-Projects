const BusinessNetworkConnection = require('composer-client').BusinessNetworkConnection;
const Table = require('cli-table');
module.exports = async function getStickers(req,res) {
    this.bizNetworkConnection = new BusinessNetworkConnection();
    var cardName = 'admin@nsf-tracking-network';
    this.businessNetworkDefinition = await this.bizNetworkConnection.connect(cardName);
    let registry = await this.bizNetworkConnection.getAssetRegistry('org.nsf.tracking.Productsticker');
    let aResources = await registry.getAll();
    let responseArray = [];
    let arrayLength = aResources.length;
    for (let i = 0; i < arrayLength; i++) {
        let tableLine = [];
        responseArray.push(aResources[i].stickerId);
        responseArray.push(aResources[i].productCode);
        responseArray.push(aResources[i].status);
        //console.log(aResources[i].owner);
        responseArray.push(aResources[i].owner.$identifier);
        
    }
    res.json(responseArray);
    
}
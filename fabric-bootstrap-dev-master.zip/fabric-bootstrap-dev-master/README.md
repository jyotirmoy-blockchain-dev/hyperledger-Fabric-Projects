# Blockchain_project_2018
composer network install --card PeerAdmin@hlfv1 --archiveFile nsf-tracking-network.bna

composer network start -n nsf-tracking-network -V 0.2.3 -A admin -S adminpw --card PeerAdmin@hlfv1 --file networkadmin.card -o endorsementPolicyFile=/path/to/file/endorsementPolicy.json
or
 composer network upgrade --card PeerAdmin@hlfv1 -n nsf-tracking-network -V 0.3.5-deploy.0

 composer card import --file networkadmin.card
// If Import card gives error navigate to .composer folder and delete the card admin@nsf-tracking-network

composer network ping --card admin@nsf-tracking-network

composer-rest-server
or
 composer-rest-server -c admin@nsf-tracking-network -n always -w true

composer-playground



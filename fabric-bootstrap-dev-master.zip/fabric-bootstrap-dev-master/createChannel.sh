#!/bin/bash
cd ./fabric-scripts/hlfv11/composer
export FABRIC_CFG_PATH=$PWD
./configtxgen -profile ComposerOrdererGenesis -outputBlock ./composer-genesis.block
./configtxgen -profile ComposerChannel -outputCreateChannelTx ./composer-channel.tx -channelID composerchannel
cd ../../../
/*
# Copyright IBM Corp. All Rights Reserved.
#
# SPDX-License-Identifier: Apache-2.0
*/

'use strict';
const shim = require('fabric-shim');
const util = require('util');

let Chaincode = class {

  // The Init method is called when the Smart Contract 'fabcar' is instantiated by the blockchain network
  // Best practice is to have any Ledger initialization in separate function -- see initLedger()
  async Init(stub) {
    console.info('=========== Instantiated fabcar chaincode ===========');
    return shim.success();
  }

  // The Invoke method is called as a result of an application request to run the Smart Contract
  // 'fabcar'. The calling application program has also specified the particular smart contract
  // function to be called, with arguments
  async Invoke(stub) {
    let ret = stub.getFunctionAndParameters();
    console.info(ret);

    let method = this[ret.fcn];
    if (!method) {
      console.error('no function of name:' + ret.fcn + ' found');
      throw new Error('Received unknown function ' + ret.fcn + ' invocation');
    }
    try {
      let payload = await method(stub, ret.params);
      return shim.success(payload);
    } catch (err) {
      console.log(err);
      return shim.error(err);
    }
  }
  // Query a perticular Book
  async queryBook(stub, args) {
    // Get arguments
    if (args.length != 1) {
      throw new Error('Incorrect number of arguments. Expecting BookId ex: INBN-0101');
    }
    let bookId = args[0];

    let bookAsBytes = await stub.getState(bookId); //get the book from chaincode state
    if (!bookAsBytes || bookAsBytes.toString().length <= 0) {
      throw new Error(bookAsBytes + ' does not exist: ');
    }
    console.log(bookAsBytes.toString());
    return bookAsBytes;
  }
  async bookHistory(stub, args) {
      if (args.length != 1) {
          throw new Error('Invalid number of arguments');
      }
      let bookId = args[0];
      let bookAsBytes = await stub.getHistoryForKey(bookId);
      if(!bookAsBytes || bookAsBytes.toString().length <= 0){
        throw new Error(bookAsBytes + ' does not exist');
      }
      console.log(bookAsBytes.toString());
      return bookAsBytes;
  }
// Initialize library books
  async initLedger(stub, args) {
    console.info('============= START : Initialize Ledger ===========');
    let books = [];
    books.push({
      name: 'BUSINESS RESEARCH METHODS',
      genre: 'MANAGEMENT',
      author: 'ZIKMUND AND BABIN',
      owner: 'NSF'
    });
    books.push({
      name: 'CONSUMER BEHAVIOR',
      genre: 'MANAGEMENT',
      author: 'MICHAEL R SOLOMON',
      owner: 'NSF'
    });
    books.push({
      name: 'SOURCING AND SUPPLY CHAIN MANAGEMENT',
      genre: 'MANAGEMENT',
      author: 'HANDFIELD MONCZKA GIUNIPERO',
      owner: 'NSF'
    });
    books.push({
      name: 'SUPPLY CHAIN MANAGEMENT',
      genre: 'MANAGEMENT',
      author: 'WISNER TAN LEONG',
      owner: 'NSF'
    });
    books.push({
      name: 'HUMAN RESOURCE MANAGEMENT',
      genre: 'MANAGEMENT',
      author: 'GARY DESSLER',
      owner: 'NSF'
    });
    books.push({
      name: 'GLOBAL STRATEGIC MANAGEMENT',
      genre: 'MANAGEMENT',
      author: 'J GEORGE FRYNAS',
      owner: 'NSF'
    });
    books.push({
      name: 'BUSINESS ETHICS',
      genre: 'MANAGEMENT',
      author: 'ANDREW CRANE',
      owner: 'NSF'
    });
    books.push({
      name: 'MICROSOFT EXCEL 2013 DATA ANALYSIS',
      genre: 'DATA ANALYSIS',
      author: 'WAYNE L WINSTON',
      owner: 'NSF'
    });
    books.push({
      name: 'COMPETITIVE STRATEGY',
      genre: 'MANAGEMENT',
      author: 'MICHAEL E POTTER',
      owner: 'NSF'
    });
    books.push({
      name: 'ENTERPRENEURSHIP',
      genre: 'MANAGEMENT',
      author: 'ARYA KUMAR',
      owner: 'NSF'
    });
    books.push({
      name: 'MANAGEMENT A GLOBAL INNOVATIVE AND ENTREPRENEURIAL PERSPECTIVE',
      genre: 'MANAGEMENT',
      author: 'HEINZ WEIHRICH, MARK V CANNICE',
      owner: 'NSF'
    });
    books.push({
      name: 'DATA MINING FOR BUSINESS INTELLIGENCE',
      genre: 'MANAGEMENT',
      author: 'GALIT SHMUELI, NITIN R PATEL, PETER C BRUCE',
      owner: 'NSF'
    });
    books.push({
      name: 'NEGOTIATING ESSENTIALS',
      genre: 'MANAGEMENT',
      author: 'MICHAEL R CARRELL, CHRISTINA HEAVRIN J.D.',
      owner: 'NSF'
    });
    books.push({
      name: 'OPERATIONS RESEARCH',
      genre: 'MANAGEMENT',
      author: 'HAMDY TAHA',
      owner: 'NSF'
    });
    books.push({
      name: 'FINANCIAL ANALYSIS AND MODELING',
      genre: 'MANAGEMENT',
      author: 'CHANDAN SENGUPTA',
      owner: 'NSF'
    });
    books.push({
      name: 'Object Oriented Programming with C++',
      genre: 'COMPUTER LANGUAGE',
      author: 'E Balaguruswamy',
      owner: 'NSF'
    });
    books.push({
      name: 'PROJECTS PLANNING, ANALYSIS',
      genre: 'MANAGEMENT',
      author: 'PRASANNA CHANDRA',
      owner: 'NSF'
    });
    books.push({
      name: 'MARKETING METRICS',
      genre: 'MANAGEMENT',
      author: 'NEIL T BENDLE',
      owner: 'NSF'
    });
    books.push({
      name: 'LAROUSSE POCKET DICTIONARY',
      genre: 'MANAGEMENT',
      author: 'FRANCIS ANGLAIS',
      owner: 'NSF'
    });
    books.push({
      name: 'BUSINESS FORECASTING WITH ACCOMPANYING EXCEL BASED FORECAST SOFTWARE',
      genre: 'MANAGEMENT',
      author: 'J HOLTON WILSON, BARRY KEATING',
      owner: 'NSF'
    });

    for (let i = 0; i < books.length; i++) {
      books[i].docType = 'book';
      await stub.putState('INBN-01' + i, Buffer.from(JSON.stringify(books[i])));
      console.info('Added <--> ', books[i]);
    }
    console.info('============= END : Initialize Ledger ===========');
  }

  async createBook(stub, args) {
    console.info('============= START : Create Book ===========');
    if (args.length != 5) {
      throw new Error('Incorrect number of arguments. Expecting 5');
    }

    var book = {
      docType: 'book',
      name: args[1],
      genre: args[2],
      author: args[3],
      owner: args[4]
    };

    await stub.putState(args[0], Buffer.from(JSON.stringify(book)));
    console.info('============= END : Create Book ===========');
  }

  async queryAllBooks(stub, args) {

    let startKey = 'INBN-010';
    let endKey = 'INBN-0120';

    let iterator = await stub.getStateByRange(startKey, endKey);

    let allResults = [];
    while (true) {
      let res = await iterator.next();

      if (res.value && res.value.value.toString()) {
        let jsonRes = {};
        console.log(res.value.value.toString('utf8'));

        jsonRes.Key = res.value.key;
        try {
          jsonRes.Record = JSON.parse(res.value.value.toString('utf8'));
        } catch (err) {
          console.log(err);
          jsonRes.Record = res.value.value.toString('utf8');
        }
        allResults.push(jsonRes);
      }
      if (res.done) {
        console.log('end of data');
        await iterator.close();
        console.info(allResults);
        return Buffer.from(JSON.stringify(allResults));
      }
    }
  }

  async changeBookOwner(stub, args) {
    console.info('============= START : changeBookOwner ===========');
    if (args.length != 2) {
      throw new Error('Incorrect number of arguments. Expecting 2');
    }

    let bookAsBytes = await stub.getState(args[0]);
    let book = JSON.parse(bookAsBytes);
    book.owner = args[1];

    await stub.putState(args[0], Buffer.from(JSON.stringify(book)));
    console.info('============= END : changeCarOwner ===========');
  }
};

shim.start(new Chaincode());

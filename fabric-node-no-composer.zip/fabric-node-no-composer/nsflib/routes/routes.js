var event = require('events');

module.exports = (app)=>{
    app.get('/allbooks', function (req, res) {
        require('../blockchainServices/query')(req, res, 'queryAllBooks','');
    });

    app.get('/book/:bookId', (req, res) => {
        require('../blockchainServices/query')(req, res, 'queryBook', req.params.bookId);
    });

    app.get('/bookhistory/:bookId', (req, res) => {
        require('../blockchainServices/query')(req, res, 'bookHistory', req.params.bookId);
    });

    app.post('/addbook',(req,res)=>{
        require('../blockchainServices/invoke')(req, res, 'createBook');
    });

    app.post('/changeOwner',(req,res)=>{
        require('../blockchainServices/invoke')(req, res, 'changeBookOwner');
    });

    app.post('/registeruser',(req,res)=>{
        require('../userRegistration/registerUser')(req,res);
    });
}
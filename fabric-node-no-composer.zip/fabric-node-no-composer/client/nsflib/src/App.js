import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import axios from 'axios';
class App extends Component {
  constructor(props) {
    super(props)
    this.state = {
      booksResults:[],
      tableContents:'',
      bookId:''
    }
  }

  componentWillMount() {
    var self = this;
      axios.get('http://52.37.117.242:3000/allbooks')
      .then(function(response){
          let results = JSON.parse(response.data.data);
          //console.log(results);
          self.setState({booksResults:results});

      })
      .catch(function(error){
        console.error(error);
        
      });
  }
  updateBookId(e){

  }
  searchBooks(e){

  }
  render() {
    return (
      <div className="">
       <div className="container">
          <div className="card">
          <div className="card-body">
            <div className="card-title"><h5>Library Books</h5></div>
            <div className="card-text">
            <div className="row">
              <div className="col-md"></div>
              <div className="col-md">
                <form className="form-inline">
                  <div className="form-group mx-sm-3 mb-2">
                    <label for="inputPassword2" className="sr-only">Book Id</label>
                    <input type="text" className="form-control" id="inputPassword2" placeholder="bookId" onChange={this.updateBookId.bind()} />
                  </div>
                  <button type="submit" className="btn btn-primary mb-2">Search</button>
                </form>
              </div>
            </div>
            <hr/>
            <table className="table">
              <thead>
                <tr>
                  <th>Book Id</th>
                  <th>Book Name</th>
                  <th>Author</th>
                  <th>Owner</th>
                </tr>
              </thead>
              <tbody>
                {this.state.booksResults.map(item=>{
                  return (
                    <tr>
                      <td>{item.Key}</td>
                      <td>{item.Record.name}</td>
                      <td>{item.Record.author}</td>
                      <td>{item.Record.owner}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            </div>
          </div>
       </div>
       </div>
      </div>
    );
  }
}

export default App;

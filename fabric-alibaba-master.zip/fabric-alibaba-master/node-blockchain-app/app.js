
var request = require('request');
const express = require('express');
const app = express()

app.get('/app/:token', (req, res) => {

    console.log(req.params.token);
    let token = req.params.token;
    //let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0aW1lc3RhbXAiOjE1MjcxNjI1MDQ3NDI1NjUwMDAsInVzZXJuYW1lIjoianl0aXJtb3luYXRoIn0.ncOeQ0XUqtX8fej-dv8JOViCf8X4E7oGZ5Ahl95p0Rc';
    let options = {
        method: 'GET',
        url: 'http://localhost:3000/auth/jwt/callback?token=' + token,
        maxRedirects: '3',
        followRedirect: false
    };

    request(options, function (error, response, body) {
        // upon a successful request, cookies are stored in response.headers['set-cookie']
        console.log(response.headers['set-cookie']);
        var data = response.headers['set-cookie'][0].split(';');
        var data2 = data[0].split('=');
        res.json({ token: data2[1]});
    });
});

app.listen(2424, () => console.log('Server Runnig on Port 2424!'));

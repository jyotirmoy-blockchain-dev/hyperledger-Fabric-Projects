const BusinessNetworkConnection = require('composer-client').BusinessNetworkConnection;
var bizNetworkConnection = new BusinessNetworkConnection();
var cardName = 'admin@nsf-tracking-network';
var businessNetworkDefinition = await bizNetworkConnection.connect(cardName);
let factory = businessNetworkDefinition.getFactory();
const namespace = 'org.nsf.tracking';
async function addAsset(req, res) {
    const ownerDetails = await bizNetworkConnection.getParticipantRegistry('org.nsf.tracking.Owner');
    //const certificateResource = [];
    let ownerFactory = factory.newResource(namespace, 'Owner', ap.ownerId);
    ownerFactory.type = ap.type;
    ownerFactory.assetCount = ap.assetCount;
    await ownerDetails.add(ownerFactory);
    // Emit Participant Added Event
    let addParticipant = factory.newEvent('org.nsf.tracking', 'Addparticipantevent');
    //console.log(addParticipant);
    addParticipant.newOwner = ownerFactory;
    emit(addParticipant);
}
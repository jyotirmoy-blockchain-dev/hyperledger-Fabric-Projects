const namespace = 'org.nsf.tracking';
var BusinessNetworkConnection = require('composer-client').BusinessNetworkConnection;
var bizNetworkConnection = new BusinessNetworkConnection();
var cardName = 'admin@nsf-tracking-network';

module.exports =  async function addParticipant(req, res) {
    // Get Information of requester
    try {
        console.log(req.body);
        var businessNetworkDefinition = await bizNetworkConnection.connect(cardName);
        let ownerId = req.body.ownerId;
        let type = req.body.type;        
        let assetCount = "0";
        let serializer = businessNetworkDefinition.getSerializer();
        let resource = serializer.fromJSON({
            '$class': 'org.nsf.tracking.addParticipant',
            'ownerId': ownerId,
            'type': type,
            'assetCount': assetCount
        });
        return await bizNetworkConnection.submitTransaction(resource);
        res.send({
            'status':'success',
            'message': 'Participant Added Successfully'
        });
    } catch (error) {
        res.send({
            'status':'Error',
            'message': error
        });
    }
}

/*
transaction addParticipant {
    o String ownerId
    o Ownertype type
    o String assetCount
}
*/
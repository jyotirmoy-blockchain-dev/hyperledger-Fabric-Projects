const express = require('express');
const app = express();
const bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));

require('./routes/routes')(app);
console.clear();

app.listen(8888, () => console.log('Server Listing on Port 8888!'));
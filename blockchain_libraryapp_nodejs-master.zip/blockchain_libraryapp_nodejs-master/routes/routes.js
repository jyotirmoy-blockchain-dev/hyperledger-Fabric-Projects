var request = require('request');
var event = require('events');
var crypto = require('crypto');
var eventEmitter = new event.EventEmitter();

var mysqlconnect = require('../db-config/dbconfig');
var checkDataIntegrity = require('../services/bcActions/checkIntegrity');

eventEmitter.on('Assetaddedevent', (args) => {
    console.log(args.body);
});
eventEmitter.on('TransferSingleasset', (args) => {
        console.log(args.body);
    }),
eventEmitter.on('Inactivateasset', (args) => {
        console.log(args.body);
    });

module.exports = (app) => {
    // Index Page
    app.get('/', function (req, res) {
        var username = req.cookies;
        if (username && !isEmpty(username)) {
            res.redirect('/dashboard');
        } else {
            res.redirect('/login');
        }
    });
    // Login Screen
    app.get('/login',function(req,res){
        res.render('login');
    });
    // Perform User Login
    app.post('/userlogin', (req, res) => {
        let username = req.body.username;        
        let password = crypto.createHash('sha512').update(req.body.password).digest('hex')
        if (username && password) {
            mysqlconnect.query('SELECT * FROM users where user = ? and password = ?', [username,password], (error, result) => {
                if (error) {
                    res.send('Error Connecting to DB');
                } else {
                    let count = result.length;
                    if (count == '1') {
                        //let data = JSON.parse(result[0]);
                        res.cookie('username',username);                        
                        req.status = 'success';
                        res.redirect('/dashboard');
                    } else {
                        /* res.json({
                            'message': 'Wrong Auth Details',
                            'status': 'Wrong user Information!'
                        }); */
                        res.render('errorlogin',{
                            errormessage: 'Wrong user Information!'
                        });
                    }
                }
            })
        } else {
            res.redirect('/');
        }
    });
    // Dashboard
    app.get('/dashboard', checkUserlogin, (req, res) => {
        require('../services/dbActions/allBooks')(req, res);
    });
    // Manage Books
    app.get('/managebooks', checkUserlogin, (req, res) => {
        require('../services/dbActions/getBooksdetails')(req, res);
    });
    // Add Books

    app.post('/addbook', checkUserlogin, function (req, res) {
        
        require('../services/bcActions/addBook')(req,res);
    });
    // Books History
    app.get('/trackissuedbooks', checkUserlogin, function (req, res) {
        require('../services/dbActions/issuedBooks')(req, res);
    });
     app.get('/availablebooks', checkUserlogin, function (req, res) {
         require('../services/dbActions/availableBooks')(req, res);
     });
    //Transfer Books
     app.get('/transferbook/:assetid', checkUserlogin, (req, res) => {
         res.render('transferbook', {
             bookId: req.params.assetid
         });
     });
     app.post('/transfer', checkUserlogin, checkDataIntegrity, (req, res) => {
         require('../services/dbActions/updateOwner')(req, res);
     });
    // Track Product Sticker
    app.get('/booktracker', checkUserlogin, (req, res) => {
        res.render('booktracker', {
            records: [],
            bookId: ''
        });
    });
    // Get ledger Information
    app.get('/ledgerinfo/:txnId', checkUserlogin, (req,res)=>{
        require('../services/bcActions/ledgerInformation')(req,res);
    });
    
    app.post('/trackbook', checkUserlogin,checkDataIntegrity, (req, res) => {
        require('../services/dbActions/trackBook')(req, res);
    });    
    app.post('/returnbooks', checkUserlogin, checkDataIntegrity, (req, res) => {
        require('../services/dbActions/updateOwner')(req,res);
    });

    app.get('/logout', (req, res) => {
         res.clearCookie('username');
         
         //res.send('Cookie deleted');
        res.redirect('/');
    });   

    app.post('/search',checkUserlogin,(req,res)=>{
        require('../services/dbActions/searchBook')(req,res);
    });

}



function checkUserlogin(req, res, next) {
    var username = req.cookies;
    if (username && !isEmpty(username)) {
        next();
    } else {
        res.redirect('/login');
    }
}

function isEmpty(myObject) {
    for (var key in myObject) {
        if (myObject.hasOwnProperty(key)) {
            return false;
        }
    }

    return true;
}
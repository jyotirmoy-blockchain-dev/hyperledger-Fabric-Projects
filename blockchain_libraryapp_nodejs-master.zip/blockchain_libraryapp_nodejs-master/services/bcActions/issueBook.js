var request = require('request');
var mysqlconnect = require('../../db-config/dbconfig');
var crypto = require('crypto');
module.exports = (req, res) => {

    mysqlconnect.query("select * from book_master where stickerId = ?", [req.body.stickerId], (error, result) => {
        let dbData = result;
        let newObj = {
            stickerId: dbData[0].stickerId,
            bookName: dbData[0].bookName,
            bookAuthor: dbData[0].bookAuthor,
            bookGenre: dbData[0].bookGenre,
            status: dbData[0].status,
            Owner: dbData[0].Owner,
        };
        let bookHash = crypto.createHash('sha512').update(JSON.stringify(newObj)).digest('hex');
        let send_data = {
            "$class": "org.nsfindialib.tracking.issueBook",
            "sticker": "resource:org.nsfindialib.tracking.Booksticker#" + req.body.stickerId,
            "newHash": bookHash
        };
        let options = {
            method: 'POST',
            url: 'http://172.17.203.69:3000/api/org.nsfindialib.tracking.issueBook',
            form: send_data
        };
        request(options, (error, response, body) => {
            if (error) {
                res.send(error);
            } else {
                let responseObj = JSON.parse(body);
                if (responseObj.error) {
                    res.status(500).send(responseObj.error.message);
                } else {
                    var date = new Date().toISOString();
                    var sql = "INSERT INTO `book_iissue_master`(`bookId`, `Owner`, `issuedOn`, transactionId) VALUES (?, ?, ?, ?)";
                    mysqlconnect.query(sql, [req.body.stickerId, req.body.newOwner, date, responseObj.transactionId], (error, result) => {
                        if (error) {
                            res.send('DB Error: ' + error);
                        } else {
                            res.redirect('/managebooks');
                        }
                    });
                }
            }
        });
    });


}
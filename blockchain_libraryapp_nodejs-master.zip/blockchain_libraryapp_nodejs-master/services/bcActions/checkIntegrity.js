var request = require('request');
var mysqlconnect = require('../../db-config/dbconfig');
var crypto = require('crypto');
function checkData (req,res,next){
    if(req.params.stickerId){
        var stickerId = req.params.stickerId;
    }
    if(req.body.stickerId){
        var stickerId = req.body.stickerId;
    }
     var options = {
         method: 'GET',
         url: "http://172.17.203.69:3000/api/queries/selectBooks?stickerid=" + stickerId
     };
     request(options, (error, response, body) => {
         if (error) {
             res.send(error);
         } else {
             let responseObj = JSON.parse(body);
            let hashData = responseObj[0].bookHash;
            mysqlconnect.query("select * from book_master where stickerId = ?",[req.body.stickerId],(error,result)=>{
                let dbData = result;
                let newObj = {
                    stickerId: dbData[0].stickerId,
                    bookName: dbData[0].bookName,
                    bookAuthor: dbData[0].bookAuthor,
                    bookGenre: dbData[0].bookGenre,
                    status: dbData[0].status,
                    Owner: dbData[0].Owner,
                };
                let bookHash = crypto.createHash('sha512').update(JSON.stringify(newObj)).digest('hex');
                if(hashData == bookHash){
                    next();
                }
                else{
                    res.send('Inconsistent Data in the database');
                }
            });
         }
     });
}

module.exports = checkData;
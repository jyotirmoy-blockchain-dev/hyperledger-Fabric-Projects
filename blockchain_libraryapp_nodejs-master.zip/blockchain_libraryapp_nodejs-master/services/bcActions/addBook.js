var request = require('request');
var crypto = require('crypto');

module.exports = (req, res) => {

    //mysqlconnect.query('insert into sticke_details values()')
    let requestObj = {
        stickerId: req.body.stickerId,
        bookName: req.body.bookName,
        bookAuthor: req.body.bookAuthor,
        bookGenre: req.body.bookGenre,
        status: 'NEW',
        Owner: 'NSF',
    };    
    req.requestObj = requestObj;

    let bookHash = crypto.createHash('sha512').update(JSON.stringify(requestObj)).digest('hex');
    let send_data = {
        "$class": "org.nsfindialib.tracking.addBook",
        "stickerId": req.body.stickerId,
        "bookHash": bookHash
    };
    let options = {
        method: 'POST',
        url: 'http://172.17.203.69:3000/api/org.nsfindialib.tracking.addBook',
        form: send_data
    };
    request(options, (error, response, body) => {
        //console.log(response);
        let errorStatus = JSON.parse(body);
        if (errorStatus.error) {
            res.status(500).send(errorStatus.error.message);
        } else {
            require('../dbActions/insertBook')(req,res);
        }
    });
}
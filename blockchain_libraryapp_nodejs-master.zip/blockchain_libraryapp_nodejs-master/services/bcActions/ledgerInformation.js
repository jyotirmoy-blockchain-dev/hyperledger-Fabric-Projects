var request = require('request');

module.exports = (req,res)=>{
    let transactionId = req.params.txnId;
    let options = {
        method: 'GET',
        url: 'http://172.17.203.69:3000/api/system/historian/'+transactionId
    };
    request(options, (error, response, body) => {
        if (error) {
            res.send(error);
        } else {
            let responseObj = JSON.parse(body);
            res.render('ledgerinfo',{
                result: responseObj
            });           
        }
    });
}
var mysqlconnect = require('../../db-config/dbconfig');
var crypto = require('crypto');

module.exports = (req, res) => {


    if (req.body.type == 'issue') {
        var sql = "update `book_master` set Owner = ?, status = 'ISSUED' where stickerId = ?";
    } else if (req.body.type == 'return') {
        var sql = "update `book_master` set Owner = ?, status = 'RETURNED' where stickerId = ?";
    }
    mysqlconnect.query(sql, [req.body.newOwner, req.body.stickerId], (error, result) => {
        if (error) {
            res.send('DB Error: ' + error);
        } else {
            // Add asset transaction to blockchain             
            // Update owner transaction 
            require('../bcActions/issueBook')(req, res);

        }
    });
}
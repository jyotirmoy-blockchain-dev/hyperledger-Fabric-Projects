var mysqlconnect = require('../../db-config/dbconfig');


module.exports = (req, res) => {

    var sql = "select * from  `book_master` WHERE 	(status = 'RETURNED' or status = 'NEW') and stickerId = ? ";
    mysqlconnect.query(sql, [req.body.stickerId], (error, result) => {
        if (error) {
            res.send('DB Error: ' + error);
        } else {
            res.render('booksavailable', {
                historyrecords: result
            });
        }
    });
}
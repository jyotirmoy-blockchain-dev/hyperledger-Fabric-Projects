var mysqlconnect = require('../../db-config/dbconfig');
var crypto = require('crypto');

module.exports = (req, res) => {
    
    requestObj = req.requestObj;
    var sql = "INSERT INTO `book_master`(stickerId,`bookName`, `bookAuthor`, `bookGenre`, `status`, `Owner`) VALUES (?, ?, ?, ?, ? , ? )";
    mysqlconnect.query(sql, [requestObj.stickerId, requestObj.bookName, requestObj.bookAuthor, requestObj.bookGenre, 'NEW', 'NSF'], (error, result) => {
        if (error) {
            res.send('DB Error: ' + error);
        } else {
            // Add asset transaction to blockchain
            //require('../bcActions/addBook')(req,res);
            res.redirect('/dashboard');
        }
    });
}
var mysqlconnect = require('../../db-config/dbconfig');


module.exports = (req, res) => {

    var sql = "SELECT * FROM `book_iissue_master` where bookId = ? order by issuedOn desc";
    mysqlconnect.query(sql,[req.body.stickerId], (error, result) => {
        if (error) {
            res.send('DB Error: ' + error);
        } else {
            res.render('booktracker', {
                records: result,
                bookId: req.body.stickerId
            });
        }
    });
}
var mysqlconnect = require('../../db-config/dbconfig');


module.exports = (req, res) => {

    var sql = "select * from  `book_master` WHERE 	status = 'ISSUED' ";
    mysqlconnect.query(sql,[req.body.stickerId], (error, result) => {
        if (error) {
            res.send('DB Error: ' + error);
        } else {
            res.render('issuedbooks', {
                historyrecords: result
            });
        }
    });
}
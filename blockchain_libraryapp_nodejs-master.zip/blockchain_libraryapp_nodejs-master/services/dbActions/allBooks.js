var mysqlconnect = require('../../db-config/dbconfig');


module.exports = (req, res) => {
    var username = req.cookies.username;
    var sql = "select * from  `book_master`";
    mysqlconnect.query(sql, (error, result) => {
        if (error) {
            res.send('DB Error: ' + error);
        } else {
            res.render('dashboard', {
                    username: username.toUpperCase(),
                    books: result
                });
        }
    });
}
var mysql = require('mysql');
var dbConfig = {
    host: '172.17.203.69',
    user: 'root',
    password: '',
    database:'lib_db'
};

const pool = mysql.createPool(dbConfig);

module.exports = pool;
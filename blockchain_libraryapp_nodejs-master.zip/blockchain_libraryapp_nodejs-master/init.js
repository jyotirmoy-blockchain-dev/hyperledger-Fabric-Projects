var mysqlconnect = require('./db-config/dbconfig');
var crypto = require('crypto');
let username = 'admin';
let password = crypto.createHash('sha512').update('password@123').digest('hex');
 var sql = "INSERT INTO users (user, password) VALUES (?, ?)";
 mysqlconnect.query('INSERT INTO users (user, password) VALUES (?, ?)', [username, password], (error, result) => {
     if (error) {
         res.send('Error Connecting to DB');
     } else {
         console.log(result);
     }
 })